<!-- # maruti-admin -->
<!-- Heading of Template -->
<h1>
  <a href="https://www.wrappixel.com/templates/maruti-admin/">Maruti Bootstrap Admin</a>
</h1>

<!-- Main image of Template -->
<a target="_blank" href="https://www.wrappixel.com/wp-content/uploads/edd/2020/04/maruti-bootstrap-admin-y.jpg">
  <img src="https://www.wrappixel.com/wp-content/uploads/edd/2020/04/maruti-bootstrap-admin-y.jpg" />
</a>

<!-- Description of Template -->
<p>
  Lorem Ipsume
</p>

<!-- Resources of Template -->
<h2>Resources</h2>
<ul>
<li>  
  Live Demo: <a href="https://www.wrappixel.com/demos/free-admin-templates/maruti-admin/index.html" rel="nofollow">https://www.wrappixel.com/demos/free-admin-templates/maruti-admin/index.html</a>
</li>
<li>
    Download Page: <a href="https://www.wrappixel.com/templates/maruti-admin/" rel="nofollow">
  https://www.wrappixel.com/templates/maruti-admin/</a>
</li>
<li>
    <a href="https://www.wrappixel.com/templates/wrapkit/#demos" rel="nofollow">WrapKit </a>Complete UI Kit - For Website Projects
</li>
</ul>

<!-- Licensing of Template -->
<h2>Licensing</h2>
<ul>
  <li>
    <p>Copyright 2020 Wrappixel (<a href="https://www.wrappixel.com/" rel="nofollow">https://www.wrappixel.com/</a>)</p>
  </li>
  <li>
    <p>Licensed under MIT (<a href="https://www.wrappixel.com/license/">https://www.wrappixel.com/license/</a>)</p>
  </li>
</ul>

<!-- Useful Links of Template -->
<h2>Useful Links</h2>
<ul>
<li><a href="https://www.wrappixel.com/templates/category/admin-template/">Admin Dashboard Template</a> from WrapPixel</li>
<li><a href="https://www.wrappixel.com/">Free Bootstrap Themes</a> from WrapPixel</li>
<li><a href="https://www.wrappixel.com/templates/category/bootstrap-admin-templates/">Bootstrap 4 Admin Dashboard Templates</a> from WrapPixel</li>
<li><a href="https://www.wrappixel.com/templates/category/angular-templates/">Angular Admin Template</a> from WrapPixel</li>
<li><a href="https://www.wrappixel.com/templates/category/react-templates/">React Products</a> from WrapPixel</li>
<li><a href="https://www.wrappixel.com/templates/category/vuejs-templates/">Vue Products</a> from WrapPixel</li>
<li><a href="https://www.wrappixel.com/templates/category/free-templates/">Free Templates</a> from WrapPixel</li>
</ul>

<!-- Social Media of Wrappixel -->
<h2>Social Media</h2>
<p>Facebook: <a href="https://www.facebook.com/wrappixel">https://www.facebook.com/wrappixel</a></p>
<p>Twitter: <a href="https://twitter.com/wrappixel">https://twitter.com/wrappixel</a></p>
<p>Medium: <a href="https://medium.com/wrappixel">https://medium.com/wrappixel</a></p>
